export JAVA=/usr/local/java/jre1.6.0_22

export PLACA=eth1
export CAPTURA=/captura
export INTERVALO=15

export ORIGEM=10.*.*.*,192.*.*.*

export FOCO1=10.*.*.*+192.*.*.*
export FOCO1_TITULO="Rede Local"

export FOCO2=!10.*.*.*+192.*.*.*
export FOCO2_TITULO="Internet"

export FOCO3=vlan100
export FOCO3_TITULO="VLAN 100"

export FOCO="$FOCO1,$FOCO2,$FOCO3"
