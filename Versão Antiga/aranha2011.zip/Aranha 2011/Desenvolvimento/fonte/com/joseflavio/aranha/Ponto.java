
/*
 *  Copyright (C) 2011 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2011
 */
public class Ponto {
	
	public Foco foco;
	
	public long pacotesEnviados = 0;
	
	public long bytesEnviados = 0;
	
	public long pacotesRecebidos = 0;
	
	public long bytesRecebidos = 0;
	
	public Ponto( Foco foco ) {
		this.foco = foco;
	}
	
	public void limpar() {
		pacotesEnviados = 0;
		bytesEnviados = 0;
		pacotesRecebidos = 0;
		bytesRecebidos = 0;
	}
	
	public Ponto copiar() {
		Ponto p = new Ponto( foco );
		p.pacotesEnviados = pacotesEnviados;
		p.pacotesRecebidos = pacotesRecebidos;
		p.bytesEnviados = bytesEnviados;
		p.bytesRecebidos = bytesRecebidos;
		return p;
	}
	
}