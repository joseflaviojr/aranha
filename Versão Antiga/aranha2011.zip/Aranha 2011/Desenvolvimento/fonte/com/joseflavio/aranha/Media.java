
/*
 *  Copyright (C) 2011 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;

import com.joseflavio.aranha.analise.Dia;
import com.joseflavio.cultura.NumeroTransformacao;
import com.joseflavio.tqc.console.AplicacaoConsole;
import com.joseflavio.tqc.console.Argumentos;
import com.joseflavio.tqc.console.Cor;
import com.joseflavio.tqc.console.SemArgumentos;
import com.joseflavio.util.CSVUtil;

/**
 * Calcula a m�dia de arquivos gerados pela {@link Analise} {@link Dia}.
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2011
 */
public class Media extends AplicacaoConsole {
	
	private File[] arquivos;
	
	public static void main( String[] args ) {
		
		Media media = new Media();
		
		try{
			
			media.inicio( args );
			
		}catch( Exception e ){
			
			media.enviarln( Cor.VERMELHA_INTENSA, e.getMessage() );
			
		}
		
	}

	@Override
	protected Argumentos processarArgumentos( String[] args ) {

		if( args.length == 0 ) throw new IllegalArgumentException( "Informe os arquivos dos quais a media sera calculada." );
		
		arquivos = new File[ args.length ];
		for( int i = 0; i < args.length; i++ ){
			arquivos[i] = new File( args[i] );
			if( ! arquivos[i].exists() ) throw new IllegalArgumentException( "Arquivo inexistente: " + args[i] );
		}
		
		return new SemArgumentos( args );
		
	}
	
	@Override
	protected void principal() {

		try{
			
			/* **************** */
			
			FileReader[] entradas = new FileReader[ arquivos.length ];
			for( int i = 0; i < arquivos.length; i++ ){
				entradas[i] = new FileReader( arquivos[i] );
			}
			
			/* **************** */
			
			StringBuilder saidaNome = new StringBuilder();
			for( File f : arquivos ){
				String nome = f.getName();
				saidaNome.append( nome.substring( 0, nome.lastIndexOf( '.' ) + 1 ) );
			}
			saidaNome.append( "csv" );
			
			File saidaArquivo = new File( saidaNome.toString() );
			if( saidaArquivo.exists() ) saidaArquivo.delete();
			saidaArquivo.createNewFile();
			FileWriter saida = new FileWriter( saidaArquivo );
			
			/* **************** */
			
			String[] colunas = new String[ 500 ];
			double[] valores = new double[ 500 ];
			int i, total = 0;
			boolean temLinhas = true;
			StringBuilder buffer = new StringBuilder( 20 );
			NumeroTransformacao mbpsFormato = Util.novaMbpsTransformacao( getCultura() );
			
			for( FileReader entrada : entradas ) total = CSVUtil.proximaLinha( entrada, colunas, ';', buffer );

			for( i = 1; i < total; i++ ) saida.write( ";" + colunas[i] );
			saida.write( '\n' );
			
			while( true ){
				String rotulo = null;
				Arrays.fill( valores, 0d );
				for( FileReader entrada : entradas ){
					if( temLinhas = CSVUtil.proximaLinha( entrada, colunas, ';', buffer ) > 0 ){
						rotulo = colunas[0];
						for( i = 1; i < total; i++ ) valores[i] += mbpsFormato.transformarReal( colunas[i] );
					}
				}
				if( temLinhas ){
					saida.write( rotulo );
					for( i = 1; i < total; i++ ) saida.write( ";" + mbpsFormato.transcrever( valores[i] / arquivos.length ) );
					saida.write( '\n' );
				}else{
					break;
				}
			}
			
			/* **************** */
			
			for( FileReader entrada : entradas ) entrada.close();
			saida.close();
			
			/* **************** */
		
		}catch( Exception e ){
			throw new IllegalArgumentException( "Erro ao processar um dos arquivos: " + e.getMessage() );
		}
		
	}
	
	@Override
	protected void fim() {
	}
	
}
