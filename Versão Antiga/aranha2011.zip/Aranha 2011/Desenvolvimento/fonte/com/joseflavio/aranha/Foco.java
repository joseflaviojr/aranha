
/*
 *  Copyright (C) 2011 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2011
 */
public class Foco {
	
	public IP ip;
	
	public MAC mac;
	
	public ToS tos;
	
	public VLAN vlan;
	
	public Foco( IP ip ) {
		this.ip = ip;
	}
	
	public Foco( MAC mac ) {
		this.mac = mac;
	}
	
	public Foco( ToS tos ) {
		this.tos = tos;
	}
	
	public Foco( VLAN vlan ) {
		this.vlan = vlan;
	}

	public boolean equivale( IP ip ){
		return this.ip != null && ip != null ? this.ip.equivale( ip ) : false;
	}
	
	public boolean equivale( MAC mac ){
		return this.mac != null && mac != null ? this.mac.equals( mac ) : false;
	}
	
	public boolean equivale( ToS tos ){
		return this.tos != null && tos != null ? this.tos.equivale( tos ) : false;
	}
	
	public boolean equivale( VLAN vlan ){
		return this.vlan != null && vlan != null ? this.vlan.equivale( vlan ) : false;
	}
	
	@Override
	public boolean equals( Object obj ) {
		Foco o = (Foco) obj;
		if( ip != null ) return o.ip != null ? ip.equals( o.ip ) : false;
		if( mac != null ) return o.mac != null ? mac.equals( o.mac ) : false;
		if( tos != null ) return o.tos != null ? tos.equals( o.tos ) : false;
		return o.vlan != null ? vlan.equals( o.vlan ) : false;
	}
	
	@Override
	public int hashCode() {
		return ip != null ? ip.hashCode() : mac != null ? mac.hashCode() : tos != null ? tos.hashCode() : vlan.hashCode();
	}
	
	public String toString() {
		return ip != null ? ip.toString() : mac != null ? mac.toString() : tos != null ? tos.toString() : vlan.toString();
	}
	
}