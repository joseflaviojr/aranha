
/*
 *  Copyright (C) 2011 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

import java.io.IOException;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2011
 */
public interface Analise {
	
	/**
	 * Prepara esta inst�ncia para uma nova an�lise.
	 */
	public void iniciar( Aranha aranha ) throws AnaliseException, IOException;
	
	/**
	 * @param pcap Cont�m o pacote corrente.
	 */
	public void analisar( LibpcapLeitor pcap ) throws AnaliseException, IOException;
	
	/**
	 * Grava as informa��es coletadas at� o momento.
	 */
	public void gravar() throws AnaliseException, IOException;
	
	/**
	 * Finaliza a an�lise, efetuando antes a �ltima {@link #gravar() grava��o}.
	 */
	public void finalizar() throws AnaliseException, IOException;
	
}
