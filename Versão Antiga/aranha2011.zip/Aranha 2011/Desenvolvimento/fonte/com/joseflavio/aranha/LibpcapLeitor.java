
/*
 *  Copyright (C) 2011 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;

import com.joseflavio.util.DataSimples;

/**
 * Leitor de pacotes gravados em arquivo de captura no formato Libpcap.
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2011
 */
public class LibpcapLeitor {
	
	private InputStream stream;
	
	private FileChannel channel;
	
	private PacoteEsperanca pacoteEsperanca;
	
	private long snaplen;
	
	private int vlanPrioridade;
	
	private int vlanCFI;
	
	private int vlanId;
	
	private int etherTipo;
	
	private byte[] macOrigem = new byte[ 6 ];
	
	private byte[] macDestino = new byte[ 6 ];
	
	private int ipTipo;

	private byte[] ipOrigem = new byte[ 4 ];
	
	private byte[] ipDestino = new byte[ 4 ];
	
	private int ipToS;
	
	private boolean tcpCompleto;
	
	private int tcpPortaOrigem;
	
	private int tcpPortaDestino;
	
	private byte[] dados = new byte[ 1500 ];
	
	private int dadosTamanho;
	
	private int dadosTamanhoOriginal;
	
	private long timestamp;
	
	private DataSimples data = new DataSimples();
	
	private boolean dataSetada = false;
	
	private byte[] pacote = new byte[ 1600 ];
	
	private int pacoteBytesLidos;
	
	private int tamanhoCapturado;
	
	private int tamanhoGravado;
	
	private long pacotesLidos = 0;
	
	private long bytesLidos = 0;
	
	private long bytesTotalTemp = 0;
	
	public LibpcapLeitor( File arquivo, PacoteEsperanca pacoteEsperanca ) throws FileNotFoundException, IOException {
		
		FileInputStream fin = new FileInputStream( arquivo );
		this.stream = new BufferedInputStream( fin, 1048576 );
		this.channel = fin.getChannel();
		
		this.pacoteEsperanca = pacoteEsperanca;

		saltar( 16 );
		this.snaplen = ler32desc();
		saltar( 4 );
		
	}

	public LibpcapLeitor( String nome, PacoteEsperanca pacoteEsperanca ) throws FileNotFoundException, IOException {
		
		this( nome != null ? new File( nome ) : null, pacoteEsperanca );
		
	}
	
	/**
	 * Efetua a leitura do pr�ximo pacote.
	 * @see PacoteEsperanca
	 */
	public final boolean lerPacote() throws IOException {
		
		if( bytesLidos >= bytesTotalTemp ){
			bytesTotalTemp = channel.size();
			if( bytesLidos >= bytesTotalTemp && ! pacoteEsperanca.esperarNovoPacote() ) return false;
		}
		
		//Libpcap
		
		timestamp = ler32desc() * 1000L;
		dataSetada = false;
		saltar( 4 );
		tamanhoGravado = (int) ler32desc();
		tamanhoCapturado = (int) ler32desc();
		
		if( timestamp < 0 || tamanhoGravado < 0 || tamanhoCapturado < 0 || tamanhoGravado > 1526 || tamanhoCapturado > 1526 ){
			while( pacoteEsperanca.esperarNovoPacote() ){
				try{
					Thread.sleep( 1000 );
				}catch( InterruptedException e ){
					throw new IOException( e );
				}
			}
			return false;
		}
		
		//Pacote
		
		int tam, tamIPCab, tamIPDados, tamTCPCab, tamTotal = tamanhoGravado;
		pacoteBytesLidos = 0;
		
		//Ethernet
		
		ler( macDestino );
		ler( macOrigem );
		etherTipo = ler16();
		tamTotal -= 14;
		
		//VLAN
		
		vlanPrioridade = -1;
		vlanCFI = -1;
		vlanId = -1;
		
		if( etherTipo == 0x8100 ){
			int vlanTag = ler16();
			vlanPrioridade = ( vlanTag & 0x0000E000 ) >> 13;
			vlanCFI = ( vlanTag & 0x00001000 ) >> 12;
			vlanId =  ( vlanTag & 0x00000FFF );
			etherTipo = ler16();
			tamTotal -= 4;
		}
		
		//IP
		
		if( etherTipo == 0x0800 ){
			
			tamIPCab = ( ler8() & 0xF ) * 4;
			ipToS = ler8();
			tamIPDados = ler16() - tamIPCab;
			saltar( 5 );
			ipTipo = ler8();
			ler16();
			ler( ipOrigem );
			ler( ipDestino );
			
			if( tamIPCab > 20 ) saltar( tamIPCab - 20 );
			tamTotal -= tamIPCab;
			
			//TCP
			
			if( ipTipo == 6 ){
				
				if( tcpCompleto = ( tamTotal >= 13 ) ){
			
					tcpPortaOrigem = ler16();
					tcpPortaDestino = ler16();
					
					if( tcpCompleto = ( tcpPortaOrigem > 0 && tcpPortaDestino > 0 ) ){
					
						saltar( 8 );
						tamTCPCab = ( ler8() >> 4 ) * 4;
						if( tamTCPCab == 0 ) tamTCPCab = 20;
			
						tam = tamTCPCab;
						if( tam > tamTotal ) tam = tamTotal;
						if( tam > 13 ) saltar( tam - 13 );
						tamTotal -= tam;
						
						// Dados TCP
						
						dadosTamanhoOriginal = tamIPDados - tamTCPCab;
						dadosTamanho = dadosTamanhoOriginal <= tamTotal ? dadosTamanhoOriginal : tamTotal;
						ler( dados, dadosTamanho );
						tamTotal -= dadosTamanho;
					
					}else{
						
						tamTotal -= 4;
						
					}
				
				}
			
			//UDP
				
			}else if( ipTipo == 17 ){
				
			}
			
		}
		
		if( tamTotal > 0 ) saltar( tamTotal );
		
		pacotesLidos++;
		
		return true;
		
	}
	
	private int ler8() throws IOException {
		
		int b;
		
		while( true ){
		
			b = stream.read();
			if( b != -1 ) break;
			
			try{
				Thread.sleep( 100 );
			}catch( InterruptedException e ){
				throw new IOException( e );
			}
			
		}
		
		pacote[ pacoteBytesLidos++ ] = (byte) b;
		bytesLidos++;
        return b;
        
    }
	
	private int ler16() throws IOException {
		
		int b1 = ler8();
        int b2 = ler8();
        
        return ( b1 << 8 ) | ( b2 << 0 );
        
    }
	
	private long ler32desc() throws IOException {
		
		int b1 = ler8();
        int b2 = ler8();
        int b3 = ler8();
        int b4 = ler8();
        
        return ( b4 << 24 ) | ( b3 << 16 ) | ( b2 << 8 ) | ( b1 << 0 );
        
    }
	
	private void ler( byte b[] ) throws IOException {
		int total = b.length;
		for( int i = 0; i < total; i++ ) b[i] = (byte) ler8();
	}
	
	private void ler( byte b[], int total ) throws IOException {
		for( int i = 0; i < total; i++ ) b[i] = (byte) ler8();
	}
	
	private void saltar( long n ) throws IOException {
		for( int i = 0; i < n; i++ ) ler8();
	}
	
	public void fechar() throws IOException {

		channel.close();
		channel = null;
		
		stream.close();
		stream = null;
		
	}
	
	public boolean isIP() {
		return etherTipo == 0x0800;
	}
	
	public boolean isUDP() {
		return ipTipo == 17;
	}
	
	public boolean isTCP() {
		return ipTipo == 6;
	}
	
	public boolean isTCPCompleto() {
		return tcpCompleto;
	}
	
	public long getSnaplen() {
		return snaplen;
	}
	
	public int getVlanPrioridade() {
		return vlanPrioridade;
	}
	
	public int getVlanCFI() {
		return vlanCFI;
	}
	
	public int getVlanId() {
		return vlanId;
	}
	
	public VLAN getVLAN() {
		return vlanId != -1 ? new VLAN( vlanId, vlanPrioridade, vlanCFI ) : null;
	}

	public int getEtherTipo() {
		return etherTipo;
	}

	public MAC getMACOrigem() {
		return new MAC( macOrigem );
	}

	public MAC getMACDestino() {
		return new MAC( macDestino );
	}
	
	public int getIPTipo() {
		return ipTipo;
	}
	
	public byte[] getIPBrutoOrigem() {
		return ipOrigem;
	}
	
	public IP getIPOrigem() {
		return new IP( ipOrigem );
	}
	
	public byte[] getIPBrutoDestino() {
		return ipDestino;
	}
	
	public IP getIPDestino() {
		return new IP( ipDestino );
	}
	
	public ToS getIPToS() {
		return new ToS( ipToS );
	}
	
	public int getTCPPortaOrigem() {
		return tcpPortaOrigem;
	}
	
	public int getTCPPortaDestino() {
		return tcpPortaDestino;
	}

	public int getDadosTamanhoOriginal() {
		return dadosTamanhoOriginal;
	}
	
	/**
	 * @see #copiarDadosPara(byte[])
	 */
	public int getDadosTamanho() {
		return dadosTamanho;
	}

	/**
	 * Copia todo o pacote.
	 * @see #getTamanhoGravado()
	 * @return destino
	 */
	public byte[] copiarPacotePara( byte[] destino ) {
		if( destino.length < tamanhoGravado ) throw new IllegalArgumentException();
		System.arraycopy( pacote, 0, destino, 0, tamanhoGravado );
		return destino;
	}
	
	/**
	 * {@link #copiarPacotePara(char[], int)} com {@link #getTamanhoGravado()}.
	 */
	public char[] copiarPacotePara( char[] destino ) {
		return copiarPacotePara( destino, tamanhoGravado );
	}
	
	/**
	 * Copia todo o pacote, convertendo cada byte diretamente para char.
	 * @param maximo M�ximo de caracteres a copiar.
	 * @see #copiarPacotePara(byte[])
	 * @return destino
	 */
	public char[] copiarPacotePara( char[] destino, int maximo ) {
		if( maximo > tamanhoGravado ) maximo = tamanhoGravado;
		if( destino.length < maximo ) throw new IllegalArgumentException();
		for( int i = 0; i < maximo; i++ ) destino[i] = (char) pacote[i];
		return destino;
	}
	
	/**
	 * Copia os dados do pacote de transporte.
	 * @see #getDadosTamanho()
	 * @return destino
	 */
	public byte[] copiarDadosPara( byte[] destino ) {
		if( destino.length < dadosTamanho ) throw new IllegalArgumentException();
		System.arraycopy( dados, 0, destino, 0, dadosTamanho );
		return destino;
	}
	
	/**
	 * {@link #copiarDadosPara(char[], int)} com {@link #getDadosTamanho()}.
	 */
	public char[] copiarDadosPara( char[] destino ) {
		return copiarDadosPara( destino, dadosTamanho );
	}
	
	/**
	 * Copia os dados do pacote de transporte, convertendo cada byte diretamente para char.
	 * @param maximo M�ximo de caracteres a copiar.
	 * @see #copiarDadosPara(byte[])
	 * @return destino
	 */
	public char[] copiarDadosPara( char[] destino, int maximo ) {
		if( maximo > dadosTamanho ) maximo = dadosTamanho;
		if( destino.length < maximo ) throw new IllegalArgumentException();
		for( int i = 0; i < maximo; i++ ) destino[i] = (char) dados[i];
		return destino;
	}
	
	/**
	 * O mesmo que {@link #copiarDadosPara(char[])}, por�m adicionando o resultado em {@link StringBuilder}.
	 * @see StringBuilder#append(char)
	 * @see #copiarDadosPara(char[])
	 * @return destino
	 */
	public StringBuilder copiarDadosPara( StringBuilder destino ) {
		for( int i = 0; i < dadosTamanho; i++ ) destino.append( (char) dados[i] );
		return destino;
	}
	
	public long getTimestamp() {
		return timestamp;
	}
	
	public long getTimestampSegundos() {
		return timestamp / 1000L;
	}
	
	public DataSimples getData() {
		if( ! dataSetada ){
			data.setTimestamp( timestamp );
			dataSetada = true;
		}
		return data;
	}
	
	public int getTamanhoCapturado() {
		return tamanhoCapturado;
	}

	public int getTamanhoGravado() {
		return tamanhoGravado;
	}
	
	public long getPacotesLidos() {
		return pacotesLidos;
	}

}
