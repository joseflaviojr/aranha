
/*
 *  Copyright (C) 2011 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha.analise;

import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

import com.joseflavio.aranha.AnaliseException;
import com.joseflavio.aranha.Aranha;
import com.joseflavio.aranha.ArquivavelAnalise;
import com.joseflavio.aranha.LibpcapLeitor;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2011
 */
public class Resumo extends ArquivavelAnalise {
	
	private long pacotes = 0;
	
	private long bytes = 0;
	
	private Protocolo[] ether = new Protocolo[ 0x10000 ];
	
	private Protocolo[] ip = new Protocolo[ 0x10000 ]; //TODO Apenas 8 bits
	
	private long tempoInicial = 0;
	
	private long tempoFinal = 0;
	
	public Resumo() {
		
		for( int i = 0; i < 0x10000; i++ ){
			ether[ i ] = new Protocolo( i );
			ip[ i ] = new Protocolo( i );
		}
		
		ether[ 0x0800 ].nome = "IPv4";
		ether[ 0x86DD ].nome = "IPv6";
		ether[ 0x0806 ].nome = "ARP";
		ether[ 0x8035 ].nome = "RARP";
		ether[ 0x8137 ].nome = "Novell";
		ether[ 0x8138 ].nome = "Novell";
		for( int i = 0x0000; i <= 0x05DC; i++ ) ether[ i ].nome = "IEEE802.3";
		for( int i = 0x6000; i <= 0x6009; i++ ) ether[ i ].nome = "DEC";
		
		ip[  6 ].nome = "TCP";
		ip[ 17 ].nome = "UDP";
		ip[  4 ].nome = "IPv4";
		ip[ 41 ].nome = "IPv6";
		ip[  1 ].nome = "ICMP";
		ip[  2 ].nome = "IGMP";
		ip[ 58 ].nome = "IPv6-ICMP";
		ip[ 89 ].nome = "OSPFIGP";
		
	}
	
	@Override
	public void iniciar( Aranha aranha ) throws AnaliseException, IOException {
		
		criarArquivo( aranha.getSaida(), "Resumo.txt" );
		
		pacotes = 0;
		bytes = 0;
		
		for( int i = 0; i < 0x10000; i++ ){
			ether[ i ].limpar();
			ip[ i ].limpar();
		}
		
		tempoInicial = 0;
		tempoFinal = 0;
		
	}
	
	public void analisar( LibpcapLeitor pcap ) throws AnaliseException, IOException {
		
		int len = pcap.getTamanhoCapturado();
		
		pacotes++;
		bytes += len;
		
		int cod = pcap.getEtherTipo() & 0xFFFF;
		ether[ cod ].pacotes++;
		ether[ cod ].bytes += len;
		
		if( pcap.isIP() ){
			cod = pcap.getIPTipo() & 0xFFFF;
			ip[ cod ].pacotes++;
			ip[ cod ].bytes += len;
		}

		if( tempoInicial == 0 ) tempoInicial = pcap.getTimestampSegundos();
		tempoFinal = pcap.getTimestampSegundos();
		
	}
	
	@Override
	public void gravar() throws AnaliseException, IOException {

		limparArquivo();
		
		escrever( "\nResumo Total\n\n" );
		
		escrever( "Pacotes = " );
		escrever( pacotes + "\n" );
		
		escrever( "Bytes = " );
		escrever( bytes + " (" + ( (float) bytes / 1048576 ) + " MB)\n" );
		
		long segundos = tempoFinal - tempoInicial;
		
		escrever( "Duracao = " + segundos + " segundos = " + ( (float) segundos / 60 ) + " minutos = " + ( (float) segundos / 3600 ) + " horas\n" );
		
		escrever( "Bytes/segundo = " + ( (float) bytes / segundos ) + "\n" );
		
		escrever( "Mbps = " + ( (float) bytes * 8 / 1000000 / segundos ) + "\n" );
		
		escrever( "\n------------------------------------------------------------------------\n" );
		escrever( "\nProtocolos Ethernet - Ordem: Bytes\n\n" );
		
		Arrays.sort(
				ether,
				new Comparator<Protocolo>() {
					public int compare( Protocolo o1, Protocolo o2 ) {
						if( o1.bytes == o2.bytes ) return 0;
						return o1.bytes > o2.bytes ? -1 : 1;
					}
				}
		);
		
		for( Protocolo prot : ether ){
			if( prot.pacotes > 0 || prot.bytes > 0 ) imprimir( prot );
		}
		
		escrever( "\n------------------------------------------------------------------------\n" );
		escrever( "\nProtocolos IP - Ordem: Bytes\n\n" );
		
		Arrays.sort(
				ip,
				new Comparator<Protocolo>() {
					public int compare( Protocolo o1, Protocolo o2 ) {
						if( o1.bytes == o2.bytes ) return 0;
						return o1.bytes > o2.bytes ? -1 : 1;
					}
				}
		);
		
		for( Protocolo prot : ip ){
			if( prot.pacotes > 0 || prot.bytes > 0 ) imprimir( prot );
		}
		
		escrever( "\n------------------------------------------------------------------------\n" );
		escrever( "\nProtocolos Ethernet - Ordem: Pacotes\n\n" );
		
		Arrays.sort(
				ether,
				new Comparator<Protocolo>() {
					public int compare( Protocolo o1, Protocolo o2 ) {
						if( o1.pacotes == o2.pacotes ) return 0;
						return o1.pacotes > o2.pacotes ? -1 : 1;
					}
				}
		);
		
		for( Protocolo prot : ether ){
			if( prot.pacotes > 0 || prot.bytes > 0 ) imprimir( prot );
		}
		
		escrever( "\n------------------------------------------------------------------------\n" );
		escrever( "\nProtocolos IP - Ordem: Pacotes\n\n" );
		
		Arrays.sort(
				ip,
				new Comparator<Protocolo>() {
					public int compare( Protocolo o1, Protocolo o2 ) {
						if( o1.pacotes == o2.pacotes ) return 0;
						return o1.pacotes > o2.pacotes ? -1 : 1;
					}
				}
		);
		
		for( Protocolo prot : ip ){
			if( prot.pacotes > 0 || prot.bytes > 0 ) imprimir( prot );
		}
		
		descarregarArquivo();
		
	}
	
	@Override
	public void finalizar() throws AnaliseException, IOException {
		gravar();
		fecharArquivo();
	}
	
	private void imprimir( Protocolo prot ) throws IOException {
		escrever( "%1$-20s", obterFormato0xFFFF( prot.codigo ) + " " + ( prot.nome != null ? prot.nome : "" ) );
		escrever( "%1$-50s", " = " + prot.pacotes + " pacotes (" + ( (float) prot.pacotes / pacotes * 100 ) + " %)" );
		escrever( " = " + prot.bytes + " bytes (" + ( (float) prot.bytes / bytes * 100 ) + " %)\n" );
	}
	
	private String obterFormato0xFFFF( int valor ) {
		String hex = Integer.toHexString( valor ).toUpperCase();
		int len = hex.length();
		if( len == 4 ) return "0x" + hex;
		if( len == 3 ) return "0x0" + hex;
		if( len == 2 ) return "0x00" + hex;
		return "0x000" + hex;
	}
	
	private class Protocolo {
		
		private int codigo;
		
		private String nome;
		
		private long pacotes = 0;
		
		private long bytes = 0;
		
		public Protocolo( int codigo ) {
			this.codigo = codigo;
		}
		
		public void limpar() {
			pacotes = 0;
			bytes = 0;
		}
		
	}
	
}
