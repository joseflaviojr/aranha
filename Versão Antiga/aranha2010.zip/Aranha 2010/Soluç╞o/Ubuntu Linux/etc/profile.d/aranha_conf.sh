export JAVA=/usr/local/java/jre1.6.0_22

export PLACA=eth0
export CAPTURA=/captura
export INTERVALO=15

export FOCO1=10.*.*.*+127.*.*.*+192.*.*.*
export FOCO1_TITULO="Rede Local"

export FOCO2=!10.*.*.*+127.*.*.*+192.*.*.*
export FOCO2_TITULO="Rede Externa"

export FOCO="$FOCO1,$FOCO2"
