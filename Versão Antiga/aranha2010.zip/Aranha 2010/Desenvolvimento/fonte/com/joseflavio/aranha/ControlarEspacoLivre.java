
/*
 *  Copyright (C) 2010 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import javax.swing.JOptionPane;

import com.joseflavio.tqc.console.AplicacaoConsole;
import com.joseflavio.tqc.console.Argumentos;
import com.joseflavio.tqc.console.ChaveadosArgumentos;
import com.joseflavio.tqc.console.SwingConsole;
import com.joseflavio.tqc.console.ChaveadosArgumentos.AdaptadoArgumentoProcessador;
import com.joseflavio.tqc.console.ChaveadosArgumentos.Chave;
import com.joseflavio.tqc.console.ChaveadosArgumentosBuilder;
import com.joseflavio.tqc.console.Cor;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2010
 */
public class ControlarEspacoLivre extends AplicacaoConsole {
	
	private File fonte = new File( System.getProperty( "user.dir" ) );
	
	private String prefixo = "cap";
	
	private String sufixo = "";
	
	private int digitos = 3;
	
	private long espaco = 512 * 1024 * 1024; //512 MB
	
	private final SimpleDateFormat logDataFormato = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
	
	public static void main( String[] args ) {
		
		ControlarEspacoLivre aplicacao = new ControlarEspacoLivre();
		
		try{
			
			aplicacao.inicio( args );
			
		}catch( Exception e ){
			
			aplicacao.enviarln( Cor.VERMELHA_INTENSA, e.getMessage() );
			mostrarErro( e.getMessage() );
			
		}
		
	}
	
	@Override
	protected Argumentos processarArgumentos( String[] args ) {

		ChaveadosArgumentos argumentos = new ChaveadosArgumentosBuilder( args )
		.mais( "-fonte", true, new Argumento_fonte() )
		.mais( "-prefixo", true, new Argumento_prefixo() )
		.mais( "-sufixo", true, new Argumento_sufixo() )
		.mais( "-digitos", true, new Argumento_digitos() )
		.mais( "-espaco", true, new Argumento_espaco() )
		.getChaveadosArgumentos();
		
		argumentos.processarArgumentos( null );
		
		if( digitos <= 0 ) throw new IllegalArgumentException( "Quantidade de digitos incorreta: " + digitos );
		
		return argumentos;
		
	}
	
	@Override
	protected void principal() {

		try{
			
			setConsole( new SwingConsole( "Aranha - Controle de Espa�o Livre" ) );

			Date data;
			long atual;
			
			while( true ){
				
				Thread.sleep( 10000 );
				
				data = new Date();
				atual = fonte.getFreeSpace();
				
				enviarln( "[" + logDataFormato.format( data ) + "] Espa�o Livre = " + (int)( atual / 1024f / 1024f ) + " MB ( M�nimo " + (int)( espaco / 1024f / 1024f ) + " )" );
				
				if( atual <= espaco ){
					
					enviarln( Cor.AMARELA, "[" + logDataFormato.format( data ) + "] Limite atingido = " + (int)( atual / 1024f / 1024f ) + " MB"  );
			
					File[] arquivos = fonte.listFiles();
					boolean apagou = false;
					
					Arrays.sort( arquivos, new TCPDumpComparator( true ) );
					
					for( File arquivo : arquivos ){
						
						String nome = arquivo.getName();
						if( nome.charAt( 0 ) == '.' ) nome = nome.substring( 1 );
						
						if( ! Util.obterPrefixo( nome ).equals( prefixo ) ) continue;
						if( ! Util.obterSufixo( nome ).equals( sufixo ) ) continue;
						if( Util.obterDigitos( nome ) != digitos ) continue;
						
						enviar( Cor.VERMELHA_INTENSA, "[" + logDataFormato.format( new Date() ) + "] Excluindo " + arquivo.getName() + "... " );
						
						apagou = arquivo.delete();
						
						enviarln( apagou ? "OK" : "ERRO" );
						
						break;
						
					}
					
					if( ! apagou ) mostrarErro( "N�o foi poss�vel apagar pelo menos um arquivo para aumentar o espa�o livre." );
				
				}
			
			}
			
		}catch( Exception e ){
			throw new IllegalArgumentException( e.getMessage() );
		}
		
	}
	
	@Override
	protected void fim() {
	}
	
	private static void mostrarErro( String mensagem ) {
		JOptionPane.showMessageDialog( null, mensagem, "Aranha: Controle de Espa�o Livre", JOptionPane.ERROR_MESSAGE );
	}
	
	private class Argumento_fonte extends AdaptadoArgumentoProcessador {
		public void processar( Chave chave, String valor ) throws IllegalArgumentException {
			fonte = new File( valor );
			if( ! fonte.exists() ) fonte = new File( new File( System.getProperty( "user.dir" ) ), valor );
			if( ! fonte.exists() || ! fonte.isDirectory() ) throw new IllegalArgumentException( "Fonte inexistente: " + valor );
		}
	}
	
	private class Argumento_prefixo extends AdaptadoArgumentoProcessador {
		public void processar( Chave chave, String valor ) throws IllegalArgumentException {
			prefixo = valor;
		}
	}
	
	private class Argumento_sufixo extends AdaptadoArgumentoProcessador {
		public void processar( Chave chave, String valor ) throws IllegalArgumentException {
			sufixo = valor;
		}
	}

	private class Argumento_digitos extends AdaptadoArgumentoProcessador {
		public void processar( Chave chave, String valor ) throws IllegalArgumentException {
			try{
				digitos = (int) getCultura().novaInteiroTransformacao().transformarInteiro( valor );
			}catch( Exception e ){
				throw new IllegalArgumentException( "Quantidade de digitos incorreta: " + valor );
			}
		}
	}
	
	private class Argumento_espaco extends AdaptadoArgumentoProcessador {
		public void processar( Chave chave, String valor ) throws IllegalArgumentException {
			try{
				espaco = getCultura().novaInteiroTransformacao().transformarInteiro( valor );
				espaco *= 1024 * 1024;
			}catch( Exception e ){
				throw new IllegalArgumentException( "Espaco livre minimo incorreto: " + valor );
			}
		}
	}
	
}
