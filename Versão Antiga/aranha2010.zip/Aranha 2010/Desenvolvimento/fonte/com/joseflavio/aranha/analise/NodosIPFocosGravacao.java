
/*
 *  Copyright (C) 2010 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha.analise;

import java.io.IOException;
import java.util.List;

import com.joseflavio.aranha.Analise;
import com.joseflavio.aranha.AnaliseException;
import com.joseflavio.aranha.Aranha;
import com.joseflavio.aranha.Foco;
import com.joseflavio.aranha.IP;
import com.joseflavio.aranha.LibpcapLeitor;

/**
 * {@link NodosIPGravacao} para cada {@link Foco} da {@link Aranha}.
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2010
 */
public class NodosIPFocosGravacao implements Analise {
	
	private IP[] focos;
	
	private NodosIPFocoGravacao[] analises;
	
	@Override
	public void iniciar( Aranha aranha ) throws AnaliseException, IOException {
		
		List<Foco> lista = aranha.getFoco();
		focos = new IP[ lista.size() ];
		analises = new NodosIPFocoGravacao[ lista.size() ];
		
		int i = 0;
		for( Foco foco : lista ){
			if( foco.ip == null ) continue;
			NodosIPFocoGravacao analise = new NodosIPFocoGravacao( foco.ip );
			analise.iniciar( aranha );
			focos[i] = foco.ip;
			analises[i] = analise;
			i++;
		}
		
	}
	
	public void analisar( LibpcapLeitor pcap ) throws AnaliseException, IOException {
		
		if( ! pcap.isIP() ) return;
		
		IP orig_ip = pcap.getIPOrigem();
		IP dest_ip = pcap.getIPDestino();

		for( int i = 0; i < focos.length; i++ ){
			IP foco = focos[i];
			if( foco.equivale( orig_ip ) || foco.equivale( dest_ip ) ){
				analises[i].analisar( pcap );
			}
		}
		
	}
	
	@Override
	public void gravar() throws AnaliseException, IOException {

		for( NodosIPFocoGravacao analise : analises ) analise.gravar();
		
	}
	
	@Override
	public void finalizar() throws AnaliseException, IOException {
		
		for( NodosIPFocoGravacao analise : analises ) analise.finalizar();
		
	}
	
}
