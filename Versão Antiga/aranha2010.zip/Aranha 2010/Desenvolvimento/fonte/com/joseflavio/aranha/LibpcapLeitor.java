
/*
 *  Copyright (C) 2010 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;

import com.joseflavio.util.DataSimples;

/**
 * Leitor de pacotes gravados em arquivo de captura no formato Libpcap.
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2010
 */
public class LibpcapLeitor {
	
	private InputStream stream;
	
	private FileChannel channel;
	
	private PacoteEsperanca pacoteEsperanca;
	
	private long snaplen;
	
	private int etherTipo;
	
	private byte[] macOrigem = new byte[ 6 ];
	
	private byte[] macDestino = new byte[ 6 ];
	
	private int ipTipo;

	private byte[] ipOrigem = new byte[ 4 ];
	
	private byte[] ipDestino = new byte[ 4 ];
	
	private boolean tcpCompleto;
	
	private int tcpPortaOrigem;
	
	private int tcpPortaDestino;
	
	private byte[] tcpDados = new byte[ 1420 ];
	
	private int tcpDadosTamanho;
	
	private int tcpDadosTamanhoOriginal;
	
	private long timestamp;
	
	private DataSimples data = new DataSimples();
	
	private boolean dataSetada = false;
	
	private int tamanhoCapturado;
	
	private int tamanhoGravado;
	
	private long pacotesLidos = 0;
	
	private long bytesLidos = 0;
	
	private long bytesTotalTemp = 0;
	
	public LibpcapLeitor( File arquivo, PacoteEsperanca pacoteEsperanca ) throws FileNotFoundException, IOException {
		
		FileInputStream fin = new FileInputStream( arquivo );
		this.stream = new BufferedInputStream( fin, 1048576 );
		this.channel = fin.getChannel();
		
		this.pacoteEsperanca = pacoteEsperanca;

		saltar( 16 );
		this.snaplen = ler32desc();
		saltar( 4 );
		
	}

	public LibpcapLeitor( String nome, PacoteEsperanca pacoteEsperanca ) throws FileNotFoundException, IOException {
		
		this( nome != null ? new File( nome ) : null, pacoteEsperanca );
		
	}
	
	/**
	 * Efetua a leitura do pr�ximo pacote.
	 * @see PacoteEsperanca
	 */
	public final boolean lerPacote() throws IOException {
		
		if( bytesLidos >= bytesTotalTemp ){
			bytesTotalTemp = channel.size();
			if( bytesLidos >= bytesTotalTemp && ! pacoteEsperanca.esperarNovoPacote() ) return false;
		}
		
		//Libpcap
		
		timestamp = ler32desc() * 1000L;
		dataSetada = false;
		saltar( 4 );
		tamanhoGravado = (int) ler32desc();
		tamanhoCapturado = (int) ler32desc();
		
		if( timestamp < 0 || tamanhoGravado < 0 || tamanhoCapturado < 0 || tamanhoGravado > 1526 || tamanhoCapturado > 1526 ){
			while( pacoteEsperanca.esperarNovoPacote() ){
				try{
					Thread.sleep( 1000 );
				}catch( InterruptedException e ){
					throw new IOException( e );
				}
			}
			return false;
		}
		
		int tam, tamIPCab, tamIPDados, tamTCPCab, tamTotal = tamanhoGravado;
		
		//Ethernet
		
		ler( macDestino );
		ler( macOrigem );
		etherTipo = ler16();
		
		tamTotal -= 14;
		
		//IP
		
		if( etherTipo == 0x0800 ){
			
			tamIPCab = ( ler8() & 0xF ) * 4;
			ler8();
			tamIPDados = ler16() - tamIPCab;
			saltar( 5 );
			ipTipo = ler8();
			ler16();
			ler( ipOrigem );
			ler( ipDestino );
			
			if( tamIPCab > 20 ) saltar( tamIPCab - 20 );
			tamTotal -= tamIPCab;
			
			//TCP
			
			if( ipTipo == 6 ){
				
				if( tcpCompleto = ( tamTotal >= 13 ) ){
			
					tcpPortaOrigem = ler16();
					tcpPortaDestino = ler16();
					
					if( tcpCompleto = ( tcpPortaOrigem > 0 && tcpPortaDestino > 0 ) ){
					
						saltar( 8 );
						tamTCPCab = ( ler8() >> 4 ) * 4;
						if( tamTCPCab == 0 ) tamTCPCab = 20;
			
						tam = tamTCPCab;
						if( tam > tamTotal ) tam = tamTotal;
						if( tam > 13 ) saltar( tam - 13 );
						tamTotal -= tam;
						
						// Dados TCP
						
						tcpDadosTamanhoOriginal = tamIPDados - tamTCPCab;
						tcpDadosTamanho = tcpDadosTamanhoOriginal <= tamTotal ? tcpDadosTamanhoOriginal : tamTotal;
						ler( tcpDados, tcpDadosTamanho );
						tamTotal -= tcpDadosTamanho;
					
					}else{
						
						tamTotal -= 4;
						
					}
				
				}
			
			}
			
		}
		
		if( tamTotal > 0 ) saltar( tamTotal );
		
		pacotesLidos++;
		
		return true;
		
	}
	
	private int ler8() throws IOException {
		
		int b;
		
		while( true ){
		
			b = stream.read();
			if( b != -1 ) break;
			
			try{
				Thread.sleep( 100 );
			}catch( InterruptedException e ){
				throw new IOException( e );
			}
			
		}
		
		bytesLidos++;
        return b;
        
    }
	
	private int ler16() throws IOException {
		
		int b1 = ler8();
        int b2 = ler8();
        
        return ( b1 << 8 ) | ( b2 << 0 );
        
    }
	
	private long ler32desc() throws IOException {
		
		int b1 = ler8();
        int b2 = ler8();
        int b3 = ler8();
        int b4 = ler8();
        
        return ( b4 << 24 ) | ( b3 << 16 ) | ( b2 << 8 ) | ( b1 << 0 );
        
    }
	
	private void ler( byte b[] ) throws IOException {
		int total = b.length;
		for( int i = 0; i < total; i++ ) b[i] = (byte) ler8();
	}
	
	private void ler( byte b[], int total ) throws IOException {
		for( int i = 0; i < total; i++ ) b[i] = (byte) ler8();
	}
	
	private void saltar( long n ) throws IOException {
		for( int i = 0; i < n; i++ ) ler8();
	}
	
	public void fechar() throws IOException {

		channel.close();
		channel = null;
		
		stream.close();
		stream = null;
		
	}
	
	public boolean isIP() {
		return etherTipo == 0x0800;
	}
	
	public boolean isUDP() {
		return ipTipo == 17;
	}
	
	public boolean isTCP() {
		return ipTipo == 6;
	}
	
	public boolean isTCPCompleto() {
		return tcpCompleto;
	}
	
	public long getSnaplen() {
		return snaplen;
	}

	public int getEtherTipo() {
		return etherTipo;
	}

	public MAC getMACOrigem() {
		return new MAC( macOrigem );
	}

	public MAC getMACDestino() {
		return new MAC( macDestino );
	}
	
	public int getIPTipo() {
		return ipTipo;
	}
	
	public byte[] getIPBrutoOrigem() {
		return ipOrigem;
	}
	
	public IP getIPOrigem() {
		return new IP( ipOrigem );
	}
	
	public byte[] getIPBrutoDestino() {
		return ipDestino;
	}
	
	public IP getIPDestino() {
		return new IP( ipDestino );
	}
	
	public int getTCPPortaOrigem() {
		return tcpPortaOrigem;
	}
	
	public int getTCPPortaDestino() {
		return tcpPortaDestino;
	}

	public int getTCPDadosTamanhoOriginal() {
		return tcpDadosTamanhoOriginal;
	}
	
	/**
	 * @see #copiarTCPDadosPara(byte[])
	 */
	public int getTCPDadosTamanho() {
		return tcpDadosTamanho;
	}
	
	/**
	 * Copia os dados do pacote TCP.
	 * @see #getTCPDadosTamanho()
	 * @return destino
	 */
	public byte[] copiarTCPDadosPara( byte[] destino ) {
		if( destino.length < tcpDadosTamanho ) throw new IllegalArgumentException();
		System.arraycopy( tcpDados, 0, destino, 0, tcpDadosTamanho );
		return destino;
	}
	
	/**
	 * {@link #copiarTCPDadosPara(char[], int)} com {@link #getTCPDadosTamanho()}.
	 */
	public char[] copiarTCPDadosPara( char[] destino ) {
		return copiarTCPDadosPara( destino, tcpDadosTamanho );
	}
	
	/**
	 * Copia os dados do pacote TCP, convertendo cada byte diretamente para char.
	 * @param maximo M�ximo de caracteres a copiar.
	 * @see #copiarTCPDadosPara(byte[])
	 * @return destino
	 */
	public char[] copiarTCPDadosPara( char[] destino, int maximo ) {
		if( maximo > tcpDadosTamanho ) maximo = tcpDadosTamanho;
		if( destino.length < maximo ) throw new IllegalArgumentException();
		for( int i = 0; i < maximo; i++ ) destino[i] = (char) tcpDados[i];
		return destino;
	}
	
	/**
	 * O mesmo que {@link #copiarTCPDadosPara(char[])}, por�m adicionando o resultado em {@link StringBuilder}.
	 * @see StringBuilder#append(char)
	 * @see #copiarTCPDadosPara(char[])
	 * @return destino
	 */
	public StringBuilder copiarTCPDadosPara( StringBuilder destino ) {
		for( int i = 0; i < tcpDadosTamanho; i++ ) destino.append( (char) tcpDados[i] );
		return destino;
	}
	
	public long getTimestamp() {
		return timestamp;
	}
	
	public long getTimestampSegundos() {
		return timestamp / 1000L;
	}
	
	public DataSimples getData() {
		if( ! dataSetada ){
			data.setTimestamp( timestamp );
			dataSetada = true;
		}
		return data;
	}
	
	public int getTamanhoCapturado() {
		return tamanhoCapturado;
	}

	public int getTamanhoGravado() {
		return tamanhoGravado;
	}
	
	public long getPacotesLidos() {
		return pacotesLidos;
	}

}
