
/*
 *  Copyright (C) 2010 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2010
 */
public class IPNegado extends IP {
	
	private IP ip;

	public IPNegado( IP ip ) {
		super( "0.0.0.0" );
		this.ip = ip;
	}
	
	@Override
	public boolean equivale( IP obj ) {
		return ! ip.equivale( obj );
	}
	
	@Override
	public boolean equals( Object obj ) {
		return ! ip.equals( obj );
	}
	
	@Override
	public int compareTo( IP obj ) {
		return ip.compareTo( obj );
	}
	
	@Override	
	public int hashCode() {
		return ip.hashCode();
	}
	
	@Override
	public String toString() {
		return '!' + ip.toString();
	}
	
}