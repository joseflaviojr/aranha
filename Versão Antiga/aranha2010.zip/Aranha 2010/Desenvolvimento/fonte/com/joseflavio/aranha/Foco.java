
/*
 *  Copyright (C) 2010 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2010
 */
public class Foco {
	
	public IP ip;
	
	public MAC mac;
	
	public Foco( IP ip ) {
		this.ip = ip;
	}
	
	public Foco( MAC mac ) {
		this.mac = mac;
	}
	
	public boolean equivale( IP ip ){
		return this.ip != null && ip != null ? this.ip.equivale( ip ) : false;
	}
	
	public boolean equivale( MAC mac ){
		return this.mac != null && mac != null ? this.mac.equals( mac ) : false;
	}
	
	@Override
	public boolean equals( Object obj ) {
		Foco o = (Foco) obj;
		if( ip != null ) return o.ip != null ? ip.equals( o.ip ) : false;
		return o.mac != null ? mac.equals( o.mac ) : false;
	}
	
	@Override
	public int hashCode() {
		return ip != null ? ip.hashCode() : mac.hashCode();
	}
	
	public String toString() {
		return ip != null ? ip.toString() : mac.toString();
	}
	
}