
/*
 *  Copyright (C) 2010 Jos� Fl�vio de Souza Dias J�nior
 *
 *  This file is part of Aranha - <http://www.joseflavio.com/aranha/>.
 *
 *  Aranha is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Aranha is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Aranha. If not, see <http://www.gnu.org/licenses/>.
 */

package com.joseflavio.aranha;

import java.io.File;
import java.util.Comparator;

/**
 * @author Jos� Fl�vio de Souza Dias J�nior
 * @version 2010
 */
public class TCPDumpComparator implements Comparator<File> {
	
	private boolean prePrefixado;
	
	public TCPDumpComparator( boolean prePrefixado ) {
		this.prePrefixado = prePrefixado;
	}

	public int compare( File o1, File o2 ) {
		String n1 = o1.getName();
		String n2 = o2.getName();
		if( n1.charAt( 0 ) == '.' ){
			if( n2.charAt( 0 ) == '.' ) return n1.compareTo( n2 );
			return prePrefixado ? -1 : 1;
		}
		if( n2.charAt( 0 ) == '.' ) return prePrefixado ? 1 : -1;
		return n1.compareTo( n2 );
	}
	
}